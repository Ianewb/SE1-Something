Couldnt figure out how to export jars with apache derby dependencies. Thus, project will have to be run from inside of an IDE.

First run LoginProtocolServer.java
Second run LoginProtocolClient.java
